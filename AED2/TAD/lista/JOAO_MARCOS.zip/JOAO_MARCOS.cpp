#include <iostream>
using namespace std;

struct no
{
  int elemento;
  no *ponteiroParaProximoNo;
};

struct corpoLista
{
  no *PrimeiroNo;
  no *UltimoNo;
  int tamanho;
};

void CrialistaVazia(corpoLista &lista) //deve ser passada por referencia pois sua modificação deve ser mostrada no programa principal (main)
{
  lista.PrimeiroNo = new no();  //Alocando dinâmicamente um nó para manipula-lo mais tarde
  lista.UltimoNo = lista.PrimeiroNo; //estou fazendo ultimos e primeiros apontarem para 
                                //a mesma posição de memoria.
  lista.UltimoNo-> ponteiroParaProximoNo = NULL; 
  //Como por enquanto este é o último elemento da lista o mesmo deve apontar para Null, 
  //indicando o fim da lista.
  lista.tamanho = 0;
}

bool verificaStatusLista(corpoLista lista)
{
  if (lista.PrimeiroNo == lista.UltimoNo)
  {
    return true ;//Então a lista está vazia
  }
  else
  {
    return false;
  }
}

int insereNaLista(corpoLista &lista, int x)
{
  
  lista.UltimoNo-> ponteiroParaProximoNo = new no(); //Criando um novo nó
  lista.UltimoNo = lista.UltimoNo-> ponteiroParaProximoNo;// Atualizando meu ponteiro ultimo para ir para o proximo nó.
  lista.UltimoNo-> elemento = x; //recebendo o número digitado pelo usuario no campo ELEMENTO
  lista.UltimoNo-> ponteiroParaProximoNo = NULL;
  lista.tamanho = lista.tamanho++;

  return lista.tamanho;
}

void ListaParImpar(corpoLista lista)
{
  corpoLista ListaPar, ListaImpar;
  no *aux, *ImprimiLista;
  
  aux = lista.PrimeiroNo-> ponteiroParaProximoNo;

  CrialistaVazia(ListaPar);
  CrialistaVazia(ListaImpar);
 
  while (aux != NULL)
  {
    if (aux-> elemento % 2 == 0)
    {
      insereNaLista(ListaPar, aux-> elemento);
    }
    else
    {
      insereNaLista(ListaImpar, aux-> elemento);
    }
    aux = aux->ponteiroParaProximoNo;
  }
  
  ImprimiLista = ListaPar.PrimeiroNo-> ponteiroParaProximoNo;
  cout<<"Imprimindo a lista Par!"<<endl;
  while (ImprimiLista != NULL)
  {
    cout<<ImprimiLista-> elemento<<" ";
    ImprimiLista = ImprimiLista->ponteiroParaProximoNo;
  }
  cout<<endl;

  ImprimiLista = ListaImpar.PrimeiroNo-> ponteiroParaProximoNo;
  cout<<"Imprimindo a lista Impar!"<<endl;
  while (ImprimiLista != NULL)
  {
    cout<<ImprimiLista-> elemento<<" ";
    ImprimiLista = ImprimiLista->ponteiroParaProximoNo;
  }
  cout<<endl;
  delete ImprimiLista;
}

void imprimeLista(corpoLista lista)
{
  no *ImprimiLista;
  int tamanho = 0;
 
  if (verificaStatusLista(lista))
  {
    cout<<"Não foi possivel imprimir a lista pois a mesma se encontra vazia!"<<endl;
  }

  else
  {
  //Recebendo o primeiro ponteiro que aponta para o proximo nó que tem elemento
  ImprimiLista = lista.PrimeiroNo-> ponteiroParaProximoNo;
  cout<<"Imprimindo a lista!"<<endl;
  while (ImprimiLista != NULL)
  {
    cout<<ImprimiLista-> elemento<<" ";
    ImprimiLista = ImprimiLista->ponteiroParaProximoNo;
  }
  delete ImprimiLista;
  }
  cout<<endl;
}
main()
{
    corpoLista lista;
    int tamanho = 0, numero;

    CrialistaVazia(lista);
    cout<<"Lista vazia criada com sucesso!"<<endl;
    cout<<endl;

    cout<<"Usuário, digite um número ou 0 para finalizar: ";
    cin>>numero;
    
    while (numero != 0)
    {
        tamanho = insereNaLista(lista, numero);
        cout<<"Usuário, digite um número ou 0 para finalizar: ";
        cin>>numero;
    }
    cout<<endl;
    imprimeLista(lista);
    cout<<"O tamanho da lista é "<<tamanho<<endl;
    cout<<endl;
    ListaParImpar(lista);
}

