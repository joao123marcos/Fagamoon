#include <iostream>
#include "lista.hpp"
using namespace std;
main()
{
  int numero = 0, escolha = 0, teste = 0, retorno = 0;
  corpoLista *lista;

  listaVazia(lista);
  cout<<"Lista vazia criada com sucesso!"<<endl;

  cout<<"Usuário, você quer inserir elementos no começo ou fim da lista? (Digite 1-Inicio ou 2-Fim)\n";
  cin>>escolha;
  cout<<endl;

  switch (escolha)
  {
  case 1:
    cout<<"Usuário, por favor digite um número ou zero para finalizar: ";
    cin>>numero;
    while (numero != 0)
    {
    insereNoInicio(lista,numero);

    cout<<"Usuário, por favor digite um número ou zero para finalizar: ";
    cin>>numero;
    teste = 1;
    }
    break;
  
  case 2:
    cout<<"Usuário, por favor digite um número ou zero para finalizar: ";
    cin>>numero;
    while (numero != 0)
    {
       insereNoFim(lista,numero);
       cout<<"Usuário, por favor digite um número ou zero para finalizar: ";
       cin>>numero;
       teste = 1;
    }
    break;

  default:
    cout<<"Escolha inválida para preenchimento da lista!";
  }
  cout<<endl;
  cout<<endl;

  retorno = imprimeLista(lista);
  cout<<endl;
 
  if (teste == 0 || retorno == 0)
  {
    cout<<"Programa Finalizado!"<<endl;
  }

  else
  {
    cout<<"Usuário, você quer que a busca de um elemento na lista seja feita por procedimento ou função?  (Digite 1-Procedimento ou 2-Função)\n";
    cin>>escolha;
    switch (escolha)
    {
    case 1:
      cout<<"Usuário, por favor digite um número para verificar se este se encontra na lista: ";
      cin>>numero;
      cout<<endl;
      procuraElementosNaLista(lista,numero);
      break;
      
    case 2:
      cout<<"Usuário, por favor digite um número para verificar se este se encontra na lista: ";
      cin>>numero;
      cout<<endl;
      bool retorno;
      retorno = FuncaoprocuraElementosNaLista(lista,numero);
      cout<<endl;
      if (retorno == true)
      {
        cout<<"Elemento encontrado na lista!"<<endl;
      }
      else
      {
        cout<<"Elemento não encontrado na lista!"<<endl;
      }
      break;

    default:
       cout<<"Opção inválida!";
    }
  }
}
