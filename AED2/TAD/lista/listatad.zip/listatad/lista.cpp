#include <iostream>
#include "lista.hpp"
using namespace std;

struct no
{
  int elemento;
  no *ponteiroParaProximoNo;
};

struct corpoLista
{
  no *PrimeiroNo;
  no *UltimoNo;
};

void listaVazia(corpoLista &lista) //deve ser passada por referencia pois sua modificação deve ser mostrada no programa principal (main)
{
  lista.PrimeiroNo = new no();  //Alocando dinâmicamente um nó para manipula-lo mais tarde
  lista.UltimoNo = lista.PrimeiroNo; //estou fazendo ultimos e primeiros apontarem para 
                                //a mesma posição de memoria.
  lista.UltimoNo-> ponteiroParaProximoNo = NULL; 
  //Como por enquanto este é o último elemento da lista o mesmo deve apontar para Null, 
  //indicando o fim da lista.
}

void insereNoFim(corpoLista &lista, int x)
{
  lista.UltimoNo-> ponteiroParaProximoNo = new no(); //Criando um novo nó
  lista.UltimoNo = lista.UltimoNo-> ponteiroParaProximoNo;// Atualizando meu ponteiro ultimo para ir para o proximo nó.
  lista.UltimoNo-> elemento = x; //recebendo o número digitado pelo usuario no campo ELEMENTO
  lista.UltimoNo-> ponteiroParaProximoNo = NULL;
}

bool verificaStatusLista(corpoLista lista)
{
  if (lista.PrimeiroNo == lista.UltimoNo)
  {
    return true;//Então a lista está vazia
  }
  else
  {
    return false;
  }
}

void insereNoInicio(corpoLista &lista, int x)
{
  no *recebePonteiro, *aux;

  if (verificaStatusLista(lista))//Verifica se a lista está vazia
  {
    lista.UltimoNo-> ponteiroParaProximoNo = new no(); //Criando um novo nó
    lista.UltimoNo = lista.UltimoNo-> ponteiroParaProximoNo;// Atualizando meu ponteiro ultimo para ir para o proximo nó.
    lista.UltimoNo-> elemento = x; //recebendo o número digitado pelo usuario no campo ELEMENTO
    lista.UltimoNo-> ponteiroParaProximoNo = NULL;
  }
  else
  {
    recebePonteiro = lista.PrimeiroNo-> ponteiroParaProximoNo;
   /*Estou guardando o ponteiro porque quando eu der o NEW para criar um novo nó eu não posso perder
    a referencia do nó já criado por causa do IF */

    lista.PrimeiroNo-> ponteiroParaProximoNo = new no();// Criei o novo nó
    aux = lista.PrimeiroNo-> ponteiroParaProximoNo;
    aux-> elemento = x;
    aux-> ponteiroParaProximoNo = recebePonteiro; 
    
  }
}

void procuraElementosNaLista(corpoLista lista, int z)
{
  no *PonteiroPercorreLista;
  bool achou = false;

  PonteiroPercorreLista = lista.PrimeiroNo-> ponteiroParaProximoNo;
  while (PonteiroPercorreLista != NULL)
  {
    if (PonteiroPercorreLista-> elemento == z)
    {
      achou = true;
    }
    PonteiroPercorreLista = PonteiroPercorreLista-> ponteiroParaProximoNo;
  }

  if (achou == true)
  {
    cout<<"Elemento encontrado na lista!"<<endl;
  }
  else
  {
    cout<<"Elemento não encontrado na lista!"<<endl;
  }
}

bool FuncaoprocuraElementosNaLista(corpoLista lista, int z)
{
  no *PonteiroPercorreLista;
  bool achou = false;

  PonteiroPercorreLista = lista.PrimeiroNo-> ponteiroParaProximoNo;
  while (PonteiroPercorreLista != NULL)
  {
    if (PonteiroPercorreLista-> elemento == z)
    {
      achou = true;
    }
    PonteiroPercorreLista = PonteiroPercorreLista-> ponteiroParaProximoNo;
  }
  return achou;
}

int imprimeLista(corpoLista lista)
{
  int retorno = 0;
  no *ImprimiLista;
  bool statusLista = false;

  statusLista = verificaStatusLista(lista);
  if (statusLista == true)
  {
    cout<<"Não foi possível imprimir a lista pois a mesma se encontra vazia"<<endl;
    retorno = 1;
    return retorno;
  }
  else
  {
  //Recebendo o primeiro ponteiro que aponta para o proximo nó que tem elemento
  ImprimiLista = lista.PrimeiroNo-> ponteiroParaProximoNo;
  cout<<"Imprimindo a lista!"<<endl;
  while (ImprimiLista != NULL)
  {
    cout<<ImprimiLista-> elemento<<" ";
    ImprimiLista = ImprimiLista->ponteiroParaProximoNo;
  }
  cout<<endl;
  retorno = 1;
  return retorno;
  delete ImprimiLista;
  /* 
  {Uma outra maniera de implementar a função de imprimir a lista
   
   no *aux;
   if(verificaStatusLista(lista)) Nesta forma simplificada ele já verifica se o resultado deste if é verdadeiro
   {
     cout<<"A lista está vazia"
   }
   else
   {
     aux = lista.PrimeiroNo-> ponteiroParaProximoNo;
     cout<<"Imprimindo a lista!"<<endl;
     while (aux != NULL)
     {
       cout<<aux-> elemento<<" ";
       aux = aux->ponteiroParaProximoNo;
     }
     cout<<endl;
    }
  }*/
  }
}
