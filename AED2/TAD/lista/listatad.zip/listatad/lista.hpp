#ifndef lista_hpp
#define lista_hpp

struct no;
struct corpoLista;

void listaVazia(corpoLista *);
void insereNoFim(corpoLista,int);
bool verificaStatusLista(corpoLista);
void insereNoInicio(corpoLista,int);
void procuraElementosNaLista(corpoLista,int);
bool FuncaoprocuraElementosNaLista(corpoLista,int);
int imprimeLista(corpoLista);

#endif






