#include<iostream>
#include "conta.hpp"
using namespace std;
main()
{
    int CPF = 0;
    float saldo = 0;
    string nome;

    cout<<"Usuário, digite seu nome!\n";
    cin>>nome;
    cout<<endl;

    cout<<"Usuário,digite seu CPF para criar a conta! ";
    cin>>CPF;
    cout<<endl;

    cout<<"Usuário, digite o seu saldo inicial para abertura da conta: ";
    cin>>saldo;
    cout<<endl;

    conta *ponteiro = criar_conta(nome,saldo,CPF);
    cout<<endl;

    conta *ponteiro = acessarNome(nome);
    cout<<endl;

    conta *ponteiro = acessarCPF(CPF);
    cout<<endl;
    
    conta *ponteiro = acessarSaldo(saldo);
    cout<<endl;



}