
#ifndef conta_bancaria_hpp
#define conta_bancaria_hpp

struct conta;

conta *criar_conta(string, float, int);
char acessarNome(conta *);
int acessarCPF(conta *);
int acessarSaldo(conta *);

#endif